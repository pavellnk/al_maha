// es6-promise/auto needed to fulfil promises for the `import()` statement in modules/index.js
import 'es6-promise/auto'
import './modules'

console.log(`app.js has loaded!`)
