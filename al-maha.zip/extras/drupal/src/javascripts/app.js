import './modules'

console.log(`app.js has loaded!`)
