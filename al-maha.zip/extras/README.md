# Extras
This folder a place for platform-specific helpers, configuration, and READMEs, as well as addtional tasks you may find helpful. The contents of a platform folder should reflect the placement of files and folders in the project directory. For example, [`extras/rails`](/gulpfile.js/extras/rails) contains `app/helpers/blendid_asset_helper.rb`, which is where the file should go in a Rails app. 

Pull requests are very welcome!
