# Blendid on Drupal

### Important Notes:
* The theme foldername is used as the basename to rename folders and config files.
